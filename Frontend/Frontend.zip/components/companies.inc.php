    <section class="companies">
      <div class="container text-center">
        <div class="row g-5">
          <div class="col-md-2">
            <img
              src="img/companies/1.png"
              alt="Company logo"
              class="img-fluid"
            />
          </div>
          <div class="col-md-2">
            <img
              src="img/companies/2.png"
              alt="Company logo"
              class="img-fluid"
            />
          </div>
          <div class="col-md-2">
            <img
              src="img/companies/3.png"
              alt="Company logo"
              class="img-fluid"
            />
          </div>
          <div class="col-md-2">
            <img
              src="img/companies/4.png"
              alt="Company logo"
              class="img-fluid"
            />
          </div>
          <div class="col-md-2">
            <img
              src="img/companies/5.png"
              alt="Company logo"
              class="img-fluid"
            />
          </div>
          <div class="col-md-2">
            <img
              src="img/companies/6.png"
              alt="Company logo"
              class="img-fluid"
            />
          </div>
        </div>
      </div>
    </section>