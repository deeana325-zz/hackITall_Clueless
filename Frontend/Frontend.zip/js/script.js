$(document).ready(function(){
    $('.search_select_box select').selectpicker();
})
