    <section class="companies">
      <div class="container text-center">
        <div class="row g-5">
          <div class="col-md-2">
            <img
              src="img/companies/3.png"
              alt="Company logo"
              class="img-fluid"
            />
          </div>
        
          <div class="col-md-2">
            <img
              src="img/companies/7.png"
              alt="Company logo"
              class="img-fluid"
            />
          </div>
        </div>
      </div>
    </section>