<?php require('components/head.inc.php'); ?>
<?php include('components/navbar.inc.php'); ?>
<?php include('components/features.inc.php'); ?>
<?php include('components/contact.inc.php'); ?>
<?php require('components/footer.inc.php'); ?>
